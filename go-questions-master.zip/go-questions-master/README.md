Preliminary information:

* Each question has a separate folder and .txt file
* Some questions have a code example in .go file
* Each question has only one correct answer
* All Questions have options from *a* to *d*
