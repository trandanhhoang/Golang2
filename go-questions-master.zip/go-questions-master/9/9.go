package main

import (
	"fmt"
)

var DEBUG bool

func main() {
	fmt.Printf("DEBUG is %t\n", DEBUG)
}
