package main

import "fmt"

const array = []float32{0.1, 0.2, 0.3}

func main() {
	fmt.Printf("%v", array)
}
