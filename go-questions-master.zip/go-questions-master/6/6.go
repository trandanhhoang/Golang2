package main

var (
	aName  string
	BigBro string
	爱      string
)

func main() {

}
