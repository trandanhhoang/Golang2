package main

import "fmt"

func main() {
	var a int8 = 3
	var b int16 = 4

	sum := a + b

	fmt.Println(sum)
}
